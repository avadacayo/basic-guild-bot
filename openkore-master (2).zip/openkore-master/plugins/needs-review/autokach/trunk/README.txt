AUTHOR: manticora
Version 3

What is the Vedro-like macros?
1. topic at rofan.ru: http://www.rofan.ru/viewtopic.php?f=32&t=7370
2. Vedro is a nickname (http://rofan.ru/memberlist.php?mode=viewprofile&u=7684). He wrote the first full-automated macro for public.
3. These plugins are used in macros: autokach.pl, macroinclude.pl and xConf.pl
3.1 macroinclude.pl - https://openkore.svn.sourceforge.net/svnroot/openkore/plugins/macroinclude/macroinclude.pl
3.2 xConf.pl - https://openkore.svn.sourceforge.net/svnroot/openkore/plugins/xconf/trunk/xconf.pl
