AUTHOR: Click, 4epT
TOPIC: http://rofan.ru/viewtopic.php?t=289