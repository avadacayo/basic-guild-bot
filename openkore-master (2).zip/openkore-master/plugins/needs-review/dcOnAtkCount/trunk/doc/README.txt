AUTHOR: KeplerBR
TOPIC: http://forums.openkore.com/viewtopic.php?f=34&t=25155&p=74352#p74352