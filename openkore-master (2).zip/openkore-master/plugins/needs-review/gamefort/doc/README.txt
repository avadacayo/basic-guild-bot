NAME: gamefort
COMPABILITY: OpenKore 2.0.7 and up
LICENCE: This plugin is licensed under the GNU GPL
TOPIC: http://forums.openkore.com/viewtopic.php?f=9&t=8242

INSTALLATION
============
copy the entire package folder to the openkore main folder
put gamefort.pl in your plugin folder and configure sys.txt to load the plugin

NOTE
====
use this plugin at your own risk