NAME:enhancedCasting
COMPABILITY:SVN
AUTHOR:xlr82xs
LICENCE:GPL
COPYRIGHT:
TOPIC:Enhanced Skill Selection based on monster HP, Race, etc


enhancedCasting.pl is the plugin itself, it goes with your plugins.
mob_db.txt is the raw Athena compatible monster database (currently for iRO) it goes with your tables.