#ifndef _DATASERVER_H_
#define _DATASERVER_H_

#include "descriptions.h"

extern DescInfo *itemsDesc;
extern DescInfo *skillsDesc;

#endif /* _DATASERVER_H_ */
