AUTHOR: KeplerBR
TOPIC:
 [EN] http://forums.openkore.com/viewtopic.php?f=34&t=29111
 [PT-BR] http://forums.openkore-brasil.com/index.php?/topic/22-jogo-da-forca/ 