<html>
	<form method="post" action="valida.php">
		<table width="250" cellpadding="1" cellspacing="3">	
		<TR> <TH COLSPAN=2>BroPLayer!</TH> </TR>
			<tr>
				<td>Usu�rio: </td>
				<td>
					<input type="text" name="user" maxlength="50" />
				</td>
			</tr>
			<tr>
				<td>Senha: </td>
				<td>
					<input type="password" name="pass" maxlength="50" />
				</td>
			</tr>
			<tr>
				<td><a href="register.php">Registrar</a> </td>
				<td>
					<input type="submit" value="login" align="center" />
				</td>
			</tr>
		</table>
	</form>
</html>