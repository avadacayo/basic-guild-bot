function LoginPopUp(){  
	window.open('login.php','Login','toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=350');  
}

function hidestatus(){
var statusmsg=""
window.status=statusmsg
return true
}

	
	

  
