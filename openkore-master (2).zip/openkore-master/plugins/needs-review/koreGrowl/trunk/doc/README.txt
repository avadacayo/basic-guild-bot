NAME: koreGrowl (growl notification support Mac OS X)
COMPABILITY: SVN revision 6464 or higher
AUTHOR: sli
LICENCE:
COPYRIGHT:
TOPIC: http://forums.openkore.com/viewtopic.php?f=34&t=2317



INSTALLATION:
-------------
You need to install Mac::Growl for this plugin. 
(This plugin is also 100% untested! ) 
See the koreSnarl thread for installation instructions and more information. 
(simply ignore the parts about Win32::Snarl.)